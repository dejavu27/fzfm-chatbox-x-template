<?php

header("Location: /player.php");
die();