<?php

require_once 'vc_shoutcast.class.php';
require_once 'vc_shoutcast_json_relay.class.php';

$vc_shoutcast = new vc_shoutcast('198.27.124.10', 5466, 'Dejavu2015!!');

$vc_shoutcast_json_relay = new vc_shoutcast_json_relay($vc_shoutcast, 60);

$vc_shoutcast_json_relay->run('both');